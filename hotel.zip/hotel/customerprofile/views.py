from tkinter import E
from django.shortcuts import render,HttpResponse,redirect
from customerprofile.form import CustomerForm
from customerprofile.models import Customermodel
def index(request):
    if request.method=="POST":
        form=CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('../show')
        else:
            pass
    else:
        obj=CustomerForm()
        return render(request,'index.html',{'stu':obj})
        
def show(request):  
        students = Customermodel.objects.all()
        return render(request,"show.html",{'stu_list':students})


def edit(request, id):  
        stu = Customermodel.objects.get(id=id)  
        return render(request,'edit.html', {'stu':stu})

def update(request, id):  
        stu =Customermodel.objects.get(id=id)  
        form=CustomerForm(request.POST, instance = stu)  
        if form.is_valid():  
            form.save()  
            return redirect("../show")
        return render(request, 'edit.html', {'stu': stu})  

def destroy(request, id):  
    stu=Customermodel.objects.get(id=id)  
    stu.delete() 
    return redirect("../show") 

def new_func():
    return redirect('show')
    
    
def upload(request):
    obj=CustomerForm()
    return render(request,'upload.html',{'stu':obj})



