from django.db import models
# Create your models here.

class Customermodel(models.Model):
    name=models.CharField(max_length=100)
    address=models.TextField()
    indate=models.CharField(max_length=150)
    outdate=models.CharField(max_length=150)

    def __str__(self):
        return str(self.name)+" "+str(self.address)

    class Meta:
        db_table='customer'

