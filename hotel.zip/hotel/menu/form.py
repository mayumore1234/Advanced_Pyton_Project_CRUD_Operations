from django import forms
#import model class from models.py
#from app_name.models import model_name
from menu.models import Menumodel

class MenuForm(forms.ModelForm):
    class Meta:
        model=Menumodel
        fields="__all__"
